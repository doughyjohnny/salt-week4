#!/usr/bin/env bash
set -e
#
# Description: Add Linux host in Nagios
#
# Author: Alan Guit
# Email: alanguit@tuta.io
# Version: 0.1
#
#

[[ ! -d /usr/local/nagios/etc/servers ]] && sudo mkdir -p /usr/local/nagios/etc/servers
# Create configuration file for host to add
sudo cat <<EOT >> /usr/local/nagios/etc/servers/ubuS2.cfg
#########################################################
# ubuS2 configuration file
#########################################################

define host {
        use                          ubuS1
        host_name                    ubuS2
        alias                        ubuS2
        address                      192.168.168.133
        register                     1
}
define service{
      host_name                       ubuS2
      service_description             PING
      check_command                   check_ping!100.0,20%!500.0,60%
      max_check_attempts              2
      check_interval                  2
      retry_interval                  2
      check_period                    24x7
      check_freshness                 1
      contact_groups                  admins
      notification_interval           2
      notification_period             24x7
      notifications_enabled           1
      register                        1
}


#########################################################
# END OF FILE
#########################################################
EOT

# Verify configuration files
nagios -v /usr/local/nagios/etc/nagios.cfg
# Restart if no errors are found
sudo service nagios restart
