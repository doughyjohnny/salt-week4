#!/usr/bin/env bash
set -e
#
# Description: Installation script LAMP stack
#
# Author: Alan Guit
# Email: alanguit@tuta.io
# Version: 0.1
#
#

# Make sure repositories are up to date
sudo apt update

# PHP installation
sudo apt install -y php7.2
# Install additional PHP modules
sudo apt install -y php7.2-curl php7.2-gd php7.2-json php7.2-mbstring php7.2-xml

# Install Apache2
sudo apt install -y apache2 libapache2-mod-php7.2

# Install MySQL with php support
sudo apt install -y mysql-server php7.2-mysql

# Secure MySQL by configuring root password
# Type Y, 2 and Y for the rest
sudo mysql_secure_installation

# Log in to MySQL with root user
sudo mysql -u root -p
# Create new MySQL user with the following queries
create user ubu@localhost identified by 'ubuS2MySQL_2#';
flush privileges;
exit

# Restart Apache2 and MySql services
sudo systemctl restart apache2.service
sudo systemctl restart mysql.service

# Configure firewall
sudo ufw allow 80/tcp
