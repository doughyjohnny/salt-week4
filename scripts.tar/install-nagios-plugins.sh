#!/usr/bin/env bash
set -e
#
# Description: Installation script Nagios plugins
#
# Author: Alan Guit
# Email: alanguit@tuta.io
# Version: 0.1
#
#

# Download and extract latest nagios-plugins source
cd /opt
wget http://www.nagios-plugins.org/download/nagios-plugins-2.2.1.tar.gz
tar xzf nagios-plugins-2.2.1.tar.gz

# Compile and install source files
cd nagios-plugins-2.2.1
./configure --with-nagios-user=nagios --with-nagios-group=nagios --with-openssl
make
make install

# Verify settings and configure nagio to start on system boot
nagios -v /usr/local/nagios/etc/nagios.cfg
sudo service nagios start
sudo systemctl enable nagios

