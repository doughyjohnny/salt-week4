#!/usr/bin/env bash
set -e
#
# Description: Configure rsyslog server
#
# Author: Alan Guit
# Email: alanguit@tuta.io
# Version: 0.1
#
#

# Install rsyslog if not installed
sudo apt install -y rsyslog

# Configure rsyslog to run in Server Mode
sudo sed -i '17c\module(load="imudp")\' /etc/rsyslog.conf
sudo sed -i '18c\input(type="imudp" port="514")\' /etc/rsyslog.conf
sudo sed -i '21c\module(load="imtcp")\' /etc/rsyslog.conf
sudo sed -i '22c\input(type="imtcp" port="514")\' /etc/rsyslog.conf

# Limit access to specific subnet
sudo sed -i '24i$AllowedSender TCP, 127.0.0.1, 192.168.168.0/24\n' /etc/rsyslog.conf


# Add templates for receiving remote messages
sudo sed -i '26i$template remote-incoming-logs,"/var/log/%HOSTNAME%/%PROGRAMNAME%.log"\n' /etc/rsyslog.conf
sudo sed -i '27i*.* ?remote-incoming-logs\n' /etc/rsyslog.conf

# Restart rsyslog for changes to take effect
sudo systemctl restart rsyslog

# Configure firewall
sudo ufw allow 514/tcp
sudo ufw allow 514/udp
