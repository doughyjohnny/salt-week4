#!/usr/bin/env bash
set -e
#
# Description: Configure rsyslog client
#
# Author: Alan Guit
# Email: alanguit@tuta.io
# Version: 0.1
#
#

# Install rsyslog if not installed
sudo apt install -y rsyslog

# Configure rsyslog.conf
sudo cat <<EOT >> /etc/rsyslog.conf
# Allow preservation of FQDN
\$PreserveFQDN on

# Remote syslog server
*.* @@192.168.168.132:514

# Actions for when rsyslog server is down
\$ActionQueueFileName queue
\$ActionQueueMaxDiskSpace 1g
\$ActionQueueSaveOnShutdown on
\$ActionQueueType LinkedList
\$ActionResumeRetryCount -1
EOT

# Restart rsyslog service
sudo systemctl restart rsyslog
