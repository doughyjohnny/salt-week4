#!/usr/bin/env bash
set -e
#
# Description: Installation script Nagios
#
# Author: Alan Guit
# Email: alanguit@tuta.io
# Version: 0.1
#
#

# Install dependencies
sudo apt update
sudo apt install -y wget build-essential unzip openssl libssl-dev
sudo apt install -y apache2 php libapache2-mod-php php-gd libgd-dev

# Create Nagios user
sudo adduser nagios
# Create group for nagios setup and add nagios user to this group and Apache group
sudo groupadd nagcmd
sudo usermod -a -G nagcmd nagios
sudo usermod -a -G nagcmd www-data

# Install Nagios Core service
cd /opt/
# Download and extract tarball
wget https://assets.nagios.com/downloads/nagioscore/releases/nagios-4.4.3.tar.gz
tar xzf nagios-4.4.3.tar.gz

# Build and compile source files
cd nagios-4.4.3
sudo ./configure --with-command-group=nagcmd
sudo make all
sudo make install
sudo make install-init
sudo make install-daemoninit
sudo make install-config
sudo make install-commandmode
sudo make install-exfoliation

# Copy event handler scripts to provide event triggers for web interface
sudo cp -R contrib/eventhandlers/ /usr/local/nagios/libexec/
sudo chown -R nagios:nagios /usr/local/nagios/libexec/eventhandlers

# Apache authentication
# Create apache configuration file for Nagios server
sudo cat <<EOT >> /etc/apache2/conf-available/nagios.conf
ScriptAlias /nagios/cgi-bin "/usr/local/nagios/sbin"

<Directory "/usr/local/nagios/sbin">
   Options ExecCGI
   AllowOverride None
   Order allow,deny
   Allow from all
   AuthName "Restricted Area"
   AuthType Basic
   AuthUserFile /usr/local/nagios/etc/htpasswd.users
   Require valid-user
</Directory>

Alias /nagios "/usr/local/nagios/share"

<Directory "/usr/local/nagios/share">
   Options None
   AllowOverride None
   Order allow,deny
   Allow from all
   AuthName "Restricted Area"
   AuthType Basic
   AuthUserFile /usr/local/nagios/etc/htpasswd.users
   Require valid-user
</Directory>
EOT

# Setup apache authentication for nagiosadmin
sudo htpasswd -c /usr/local/nagios/etc/htpasswd.users nagiosadmin

# Enable apache configuration and restart Apache
sudo a2enconf nagios
sudo a2enmod cgi rewrite
sudo systemctl restart apache2

sudo ln -s /usr/local/nagios/bin/nagios /bin

# Install NRPE plugin
sudo apt install -y nagios-nrpe-plugin
sudo ln -s /usr/lib/nagios/plugins/check_nrpe /bin
