#!/usr/bin/env bash
set -e
#
# Description: Installation script NRPE on remote host
#
# Author: Alan Guit
# Email: alanguit@tuta.io
# Version: 0.1
#
#

# Install NRPE
sudo apt update
sudo apt install -y nagios-nrpe-server nagios-plugins

# Add nagios monitoring server IP address to allowed hosts list
sudo sed -i '106c\allowed_hosts=127.0.0.1, 192.168.168.132\' /etc/nagios/nrpe.cfg

# Restart the NRPEservice
sudo /etc/init.d/nagios-nrpe-server restart
